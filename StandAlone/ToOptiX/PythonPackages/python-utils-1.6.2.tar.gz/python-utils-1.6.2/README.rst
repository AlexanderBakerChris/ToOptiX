Introduction
============

Travis status:

.. image:: https://travis-ci.org/WoLpH/python-utils.png?branch=master
  :target: https://travis-ci.org/WoLpH/python-utils

Coverage:

.. image:: https://coveralls.io/repos/WoLpH/python-utils/badge.png?branch=master
  :target: https://coveralls.io/r/WoLpH/python-utils?branch=master

Python Utils is a collection of small Python functions and
classes which make common patterns shorter and easier. It is by no means a
complete collection but it has served me quite a bit in the past and I will
keep extending it.

One of the libraries using Python Utils is Django Utils.

Documentation is available at: http://python-utils.readthedocs.org/en/latest/


__version__ = '1.6.2'
__author__ = 'Rick van Hattem'
__author_email__ = 'Rick.van.Hattem@Fawo.nl'
__description__ = ('Python Utils is a module with some convenient utilities '
    'not included with the standard Python install')

